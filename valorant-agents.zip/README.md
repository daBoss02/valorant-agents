## Valorant Agents

Using the [Valorant API](https://valorant-api.com/v1/agents)
Using React

Click [here](https://daboss02.github.io/valorant-agents/) to view a live demo.